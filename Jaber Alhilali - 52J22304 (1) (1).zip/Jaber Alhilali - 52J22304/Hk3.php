<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AL MUYASSIR</title>
    <style>
        /* Resetting margin and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            background-color: grey;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 30px;
        }

        a {
            color: white;
            text-decoration: none;
        }

        .logo {
            font-size: 30px;
        }

        ul {
            width: 40%;
            list-style: none;
            display: flex;
            justify-content: space-between;
            margin-right: 70px;
        }

        ul a {
            border-bottom: 2px solid transparent;
        }

        ul a:hover {
            border-bottom-color: white;
        }

        /* Form styling */
        .form-container {
            max-width: 600px;
            margin: 100px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            font-family: Arial, sans-serif;
        }

        h2 {
            font-family: 'Amiri', serif;
            font-size: 24px;
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .cancel-btn {
            background-color: #555;
        }

        .cancel-btn:hover {
            background-color: #333;
        }

        .submit-btn {
            background-color: #007bff;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .form-container {
                width: 90%;
            }
        }
        
        @import url(https://fonts.googleapis.com/earlyaccess/amiri.css);
    </style>
    <script>
        function toggleAdditionalFields() {
            const serviceSelect = document.getElementById("service");
            const expiryFields = document.getElementById("expiry-fields");
            const carPlateField = document.getElementById("car-plate-field");

            if (serviceSelect.value === "Renew National Identity Card" || 
                serviceSelect.value === "Renew Driving Licence" || 
                serviceSelect.value === "Passport") {
                expiryFields.style.display = "block";
                carPlateField.style.display = "none";
            } else if (serviceSelect.value === "Car") {
                expiryFields.style.display = "none";
                carPlateField.style.display = "block";
            } else {
                expiryFields.style.display = "none";
                carPlateField.style.display = "none";
            }
        }
    </script>
</head>

<body>

    <header>
        <a href="#" class="logo" style="font-family:'Amiri', serif;">المُيــسّر</a>
        <ul>
            <li><a href="Hk.html">HOME</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CONTACT US</a></li>
            <li><a href="#">ABOUT US</a></li>
        </ul>
    </header>

    <div class="form-container">
        <h2>Documents Renew</h2>
        <form>
            <div class="form-group">
                <label for="full-name">Full Name</label>
                <input type="text" id="full-name" name="full-name" required>
            </div>

            <div class="form-group">
                <label for="id">ID</label>
                <input type="text" id="id" name="id" required>
            </div>

            <div class="form-group">
                <label for="phone-number">Phone Number</label>
                <input type="text" id="phone-number" name="phone-number" required>
            </div>

            <div class="form-group">
                <label for="wilayah">Wilayah</label>
                <select id="wilayah" name="wilayah" required>
                    <option value="Barka">Barka</option>
                    <option value="Muscat">Muscat</option>
                    <option value="Rustaq">Rustaq</option>
                    <option value="Mussanah">Mussanah</option>
                    <option value="Sohar">Sohar</option>
                    <option value="Khaborah">Khaborah</option>
                </select>
            </div>

            <div class="form-group">
                <label for="service">Service</label>
                <select id="service" name="service" onchange="toggleAdditionalFields()" required>
                    <option value="Renew National Identity Card">Renew National Identity Card</option>
                    <option value="Renew Driving Licence">Renew Driving Licence</option>
                    <option value="Car">Car</option>
                    <option value="Passport">Passport</option>
                </select>
            </div>

            <div id="expiry-fields" style="display: none;">
                <div class="form-group">
                    <label for="expiry-date">Expiry Date</label>
                    <input type="date" id="expiry-date" name="expiry-date">
                </div>

                <div class="form-group">
                    <label for="dob">Date of Birth</label>
                    <input type="date" id="dob" name="dob">
                </div>
            </div>

            <div id="car-plate-field" style="display: none;">
                <div class="form-group">
                    <label for="car-plate-number">Car Plate Number</label>
                    <input type="text" id="car-plate-number" name="car-plate-number">
                </div>
            </div>

            <div class="form-actions">
                <button type="button" class="cancel-btn">Cancel</button>
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>

</body>
</html>
