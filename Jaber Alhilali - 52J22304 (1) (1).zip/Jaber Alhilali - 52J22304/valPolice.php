<?php
if (isset($_POST['submit-btn'])) {
    $errors = [];

    if (!isset($_POST['full-name']) || empty(trim($_POST['full-name']))) {
        $errors[] = "Full Name is required.";
    }

    if (!isset($_POST['id']) || empty(trim($_POST['id']))) {
        $errors[] = "ID is required.";
    }

    if (!isset($_POST['phone-number']) || empty(trim($_POST['phone-number']))) {
        $errors[] = "Phone Number is required.";
    } elseif (!preg_match('/^[79]\d{7}$/', $_POST['phone-number'])) {
        $errors[] = "Phone Number must be 8 digits and start with 7 or 9.";
    }

    if (!isset($_POST['wilayah']) || empty($_POST['wilayah'])) {
        $errors[] = "Please select a Wilayah.";
    }

    if (!isset($_POST['service']) || empty($_POST['service'])) {
        $errors[] = "Please select a Service.";
    } else {
        if ($_POST['service'] === "Renew National Identity Card" || 
            $_POST['service'] === "Renew Driving Licence" || 
            $_POST['service'] === "Passport") {
            if (!isset($_POST['expiry-date']) || empty($_POST['expiry-date'])) {
                $errors[] = "Expiry Date is required for the selected service.";
            }
            if (!isset($_POST['dob']) || empty($_POST['dob'])) {
                $errors[] = "Date of Birth is required for the selected service.";
            }
        } elseif ($_POST['service'] === "Car") {
            if (!isset($_POST['car-plate-number']) || empty(trim($_POST['car-plate-number']))) {
                $errors[] = "Car Plate Number is required.";
            } elseif (!preg_match('/^\d{1,5}\/[A-Za-z]{1,2}$/', $_POST['car-plate-number'])) {
                $errors[] = "Car Plate Number must follow the format (Number/Letter) Ex:(33922/HH).";
            }
        }
    }

    if (!empty($errors)) {
        echo "<h2>Errors:</h2>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
        echo '<a href="javascript:history.back()">Go Back</a>';
    } else {
        echo "<h2>Form is valid!</h2>";
    }
}
?>

