<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "muyassair";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $ser = $_POST['service'];
    
    // Fields for School Registration
    $gfname = $_POST['guardian-full-name'];
    $gphone = $_POST['guardian-phone-number'];
    $gid = $_POST['guardian-id'];
    $wi = $_POST['wilayah'];
    $add = $_POST['home-address'];
    $sfname = $_POST['student-full-name'];
    $spass = $_POST['student-passport-number'];
    $sage = $_POST['student-age'];

    // Fields for Commercial Register
    $fname = $_POST['full-name'];
    $id = $_POST['id'];
    $phone = $_POST['phone-number'];
    $wilayah = $_POST['wilayah-c'];
    $bname = $_POST['business-name'];
    $ob = $_POST['business-ownership-type'];

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($ser === "School Registration") {
            // Insert into School Registration table
            $sql = "INSERT INTO school_rejestration(service, g_full_name, g_phone_number, g_id, wilayah, home_address, s_full_name, s_passport, s_age)
                    VALUES ('$ser', '$gfname', '$gphone', '$gid', '$wi', '$add', '$sfname', '$spass', '$sage')";
        } elseif ($ser === "Commercial Register") {  // Change this to "Commercial register"
            // Insert into Commercial Register table
            $sql = "INSERT INTO commerial_rejesteration(service, full_name, nat_id, phone_number, wilayah, business_name, business_ownership)
                    VALUES ('$ser', '$fname', '$id', '$phone', '$wilayah', '$bname', '$ob')";
        } else {
            throw new Exception("Unsupported service type.");
        }

        // Execute the query
        $conn->exec($sql);
        echo "New record created successfully";

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}

$conn = null;
?>
