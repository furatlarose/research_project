<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "muyassair";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $service = $_POST['service'];
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($service == "Traveling Visa") {
            $fullName = $_POST['visa-full-name'];
            $phone = $_POST['visa-phone-number'];
            $id = $_POST['visa-id'];
            $passport = $_POST['visa-passport-number'];
            $country = $_POST['visa-country'];
            $term = $_POST['visa-term'];

            $sql = "INSERT INTO travelling_visa (service, full_name, phone_number, nat_id, passport, country_travel, term) 
                    VALUES ('$service', '$fullName', '$phone', '$id', '$passport', '$country', '$term')";

        } elseif ($service == "Support Outside Country") {
            $fullName = $_POST['support-full-name'];
            $phone = $_POST['support-phone-number'];
            $id = $_POST['support-id'];
            $whoNeedsSupport = $_POST['who-need-support'];

            if ($whoNeedsSupport == "Another Person") {
                $anotherFullName = $_POST['another-person-full-name'];
                $anotherPhone = $_POST['another-person-phone'];
                $anotherId = $_POST['another-person-id'];

                $sql = "INSERT INTO support_outside_country (service, full_name, phone_number, nat_id, need_support, another_full_name, another_phone_number, another_id) 
                        VALUES ('$service', '$fullName', '$phone', '$id', '$whoNeedsSupport', '$anotherFullName', '$anotherPhone', '$anotherId')";
            } else {
                $sql = "INSERT INTO support_outside_country (service, full_name, phone_number, nat_id, need_support) 
                        VALUES ('$service', '$fullName', '$phone', '$id', '$whoNeedsSupport')";
            }

        } elseif ($service == "Consultations") {
            $fullName = $_POST['consult-full-name'];
            $phone = $_POST['consult-phone-number'];
            $id = $_POST['consult-id'];
            $topic = $_POST['consult-topic'];

            $sql = "INSERT INTO consultations (service, full_name, phone_number, nat_id, consultation_topic) 
                    VALUES ('$service', '$fullName', '$phone', '$id', '$topic')";

        } elseif ($service == "Book Appointment") {
            $fullName = $_POST['appointment-full-name'];
            $phone = $_POST['appointment-phone'];
            $id = $_POST['appointment-id'];
            $time = $_POST['appointment-time'];
			$date = $_POST['appointment-date'];

            $sql = "INSERT INTO book_appointment (service, full_name, phone_number, nat_id, sel_time , date) 
                    VALUES ('$service', '$fullName', '$phone', '$id', '$time', $date)";

        } 
        // Execute the SQL statement
        $conn->exec($sql);
        echo "New record created successfully";

    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

$conn = null;
?>
