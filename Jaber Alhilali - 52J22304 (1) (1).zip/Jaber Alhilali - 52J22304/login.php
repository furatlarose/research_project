
<?php
// login.php

// Start the session
session_start();

// Database connection
$host = "localhost"; // Database host
$username = "root";  // Database username
$password = "";      // Database password
$dbname = "muyassair"; // Your database name

$conn = new mysqli($host, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the phone number from the form
    $phoneNumber = $_POST['phone-number'];

    // Query to check if the phone number exists
    $stmt = $conn->prepare("SELECT phone_number FROM rejester WHERE phone_number = ?");
    $stmt->bind_param("s", $phoneNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Set session variables
        $_SESSION['loggedin'] = true;
        $_SESSION['phone'] = $phoneNumber;

        // Check if the phone number matches the admin identifier
        if ($phoneNumber === "admin") {
            // Redirect to show_data.php if the user is an admin
            header("Location: show data.php");
        } else {
            // Redirect to nextpage.php if the user is not an admin
            header("Location: nextpage.php");
        }
        exit();
    } else {
        // Phone number not found
        $error = "Phone number not found. Please try again.";
    }

    $stmt->close();
}

$conn->close();
?>





<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AL MUYASSIR - Login</title>
    <style>
        /* Resetting margin and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            background-color: #000c71;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 30px;
        }

        a {
            color: white;
            text-decoration: none;
        }

        .logo {
            font-size: 30px;
        }

        ul {
            width: 40%;
            list-style: none;
            display: flex;
            justify-content: space-between;
            margin-right: 70px;
        }

        ul a {
            border-bottom: 2px solid transparent;
        }

        ul a:hover {
            border-bottom-color: white;
        }

        /* Form styling */
        .form-container {
            max-width: 400px;
            margin: 100px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            font-family: Arial, sans-serif;
        }

        h2 {
            font-family: 'Amiri', serif;
            font-size: 24px;
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-actions {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .form-container {
                width: 90%;
            }
        }
        
        @import url(https://fonts.googleapis.com/earlyaccess/amiri.css);
    </style>
</head>

<body>

    <header>
        <a href="Hk.html" class="logo" style="font-family:'Amiri', serif;">المُيــسّر</a>
        <ul>
            <li><a href="Hk.html">HOME</a></li>
            <li><a href="Hk8.html">SERVICES</a></li>
            <li><a href="Hk11.html">REJESTER</a></li>
            <li><a href="Hk13.html">ABOUT US</a></li>
        </ul>
    </header>

    <div class="form-container">
            <h2>Login</h2>
    <?php if (isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
    <form action="login.php" method="POST">
        <label for="phone-number">Phone Number:</label>
        <input type="text" id="phone-number" name="phone-number" required>
		<br>
		<br>
        <button type="submit">Login</button>
    </form>

            
        </form>
    </div>

</body>
</html>
