<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="ssc.css">
    <style>
      /* General body styling */
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background-color: #f9f9f9;
    line-height: 1.6;
}

/* Table styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 18px;
    text-align: left;
    background-color: #ffffff;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
}

/* Table header styling */
th {
    background-color: blue;
    color: white;
    padding: 10px;
    border: 1px solid #dddddd;
}

/* Table cell styling */
td {
    border: 1px solid #dddddd;
    padding: 10px;
    color: #333333;
}

/* Alternating row colors */
tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #c9cfff;
    transition: background-color 0.3s ease;
}

/* Buttons styling */
button {
    background-color: blue;
    color: white;
    border: none;
    padding: 8px 12px;
    margin: 2px;
    font-size: 14px;
    cursor: pointer;
    border-radius: 3px;
}

button:hover {
    background-color:red ;
}

button:active {
    background-color: #3e8e41;
    transform: scale(0.98);
}

/* Input fields styling */
input[type="text"] {
    padding: 6px;
    font-size: 14px;
    margin: 2px;
    border: 1px solid #ccc;
    border-radius: 3px;
    width: calc(100% - 14px); /* Adjust for padding and border */
}

/* Styling for action buttons container */
.actions {
    text-align: center;
}
header{background-color:blue;}
    </style>
</head>
<body>
<header>
<a href="#" class="logo" style="font-family:'Amiri', serif;">المُيــسّر</a>  
<ul>
<li><a href="Hk.html">HOME</a></li>
<li><a href="logout.php">LOG OUT</a></li>



</ul>
</header>

<?php
// Your PHP code as provided
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "muyassair";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Skip displaying data if phone_number is admin
    $adminPhone = "admin";
    $stmt = $conn->prepare("SELECT full_name, phone_number, wilayah, time FROM rejester WHERE phone_number != ?");
    $stmt->execute([$adminPhone]);

    echo "<table>
            <tr>
                <th>Full Name</th>
                <th>Phone Number</th>
                <th>Wilayah</th>
                <th>Time</th>
				<th>Edit</th>
            </tr>";

    foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['phone_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['wilayah']) . "</td>";
        echo "<td>" . htmlspecialchars($row['time']) . "</td>";

        // Add Update and Delete buttons
        echo "<td style='border: 1px solid black;'>
              <form action='update.php' method='post' style='display:inline;'>
                    <p> Fill Name:<input type='text' name='full-name' value='" . htmlspecialchars($row['full_name']) . "'></p>
                    <p> Phone Number:<input type='text' name='phone-number1' value='" . htmlspecialchars($row['phone_number']) . "' placeholder='old phone'></p>
                    <input type='hidden' name='phone-number2' value='" . htmlspecialchars($row['phone_number']) . "' placeholder='updated phone'>
                    <p> Wilayah:<input type='text' name='w' value='" . htmlspecialchars($row['wilayah']) . "' placeholder='wilayah'></p>
                    <button type='submit'>Update</button>
                </form>
                <form action='delete.php' method='post' style='display:inline;'>
                    <input type='hidden' name='phone-number' value='" . htmlspecialchars($row['phone_number']) . "'>
                    <button type='submit' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</button>
                </form>
              </td>";

        echo "</tr>";
    }
    echo "</table>";

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
?>

</body>
</html>
