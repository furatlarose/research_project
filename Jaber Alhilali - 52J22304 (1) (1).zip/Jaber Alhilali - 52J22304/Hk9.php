<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "muyassair";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $ser = $_POST['service'];
    
    // Fields for Rent Home
    $tfname = $_POST['tenant-full-name'];
    $tphone = $_POST['tenant-phone-number'];
    $tid = $_POST['tenant-id-number'];
    $rfname = $_POST['renter-full-name'];
    $rphone = $_POST['renter-phone-number'];
    $rid = $_POST['renter-id-number'];
    $realid = $_POST['realestate-id'];

    // Fields for Building Management
    $mfname = $_POST['manager-full-name'];
    $mphone = $_POST['manager-phone-number'];
    $mid = $_POST['manager-id-number'] ;
    $mrealid = $_POST['manager-realestate-id'] ;

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($ser === "Rent Home") {
            // Insert into Rent Home table
            $sql = "INSERT INTO rent_home(service, t_full_name, t_phone_number, t_nat_id, r_full_name, r_phone_number, r_nat_id, realestate_id)
                    VALUES ('$ser', '$tfname', '$tphone', '$tid', '$rfname', '$rphone', '$rid', '$realid')";
        } elseif ($ser === "Building Management") {
            // Insert into Building Management table
            $sql = "INSERT INTO buliding_management(service, full_name, phone_number, nat_id, real_id)
                    VALUES ('$ser', '$mfname', '$mphone', '$mid', '$mrealid')";
        } else {
            throw new Exception("Unsupported service type.");
        }

        // Execute the query
        $conn->exec($sql);
        echo "New record created successfully";

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}

$conn = null;
?>
