<?php
// nextpage.php

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AL MUYASSIR</title>
    <style>
        /* Resetting margin and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            background-color: #000c71;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 30px;
        }

        a {
            color: white;
            text-decoration: none;
        }

        .logo {
            font-size: 30px;
        }

        ul {
            width: 40%;
            list-style: none;
            display: flex;
            justify-content: space-between;
            margin-right: 70px;
        }

        ul a {
            border-bottom: 2px solid transparent;
        }

        ul a:hover {
            border-bottom-color: white;
        }

        .content {
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 40px;
            width: 100%;
            flex-wrap: wrap;
            background-color: #000c71;
            color: #333;
            font-family: Arial, sans-serif;
            position: relative;
            bottom: -170px;
        }

        .service {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 200px;
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .service:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .service img {
            width: 60px;
            height: 60px;
            margin-bottom: 15px;
        }

        .service h3 {
            font-size: 18px;
            margin: 10px 0;
            color: #333;
        }

        .service p {
            font-size: 14px;
            color: #555;
        }

        .logout-container {
            text-align: center;
            margin: 50px auto;
            padding: 10px;
            background-color: #fff; /* Add background for visibility */
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: fit-content;
        }

        .logout-btn {
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .content {
                flex-direction: column;
                align-items: center;
            }
        }

        @import url(https://fonts.googleapis.com/earlyaccess/amiri.css);
    </style>
</head>

<body>
    <header>
        <a href="Hk.html" class="logo" style="font-family:'Amiri', serif;">المُيــسّر</a>
        <ul>
            <li><a href="Hk.html">HOME</a></li>
            <li><a href="Hk8.html">SERVICES</a></li>
            <li><a href="Hk10.html">REJESTER</a></li>
            <li><a href="Hk13.html">ABOUT US</a></li>
        </ul>
    </header>

    <div class="content">
        <!-- Service 1 -->
        <div class="service">
            <a href="Hk4.html"><img src="police2.png" alt="Renew Documents Icon">
            <h3>Renew Documents</h3>
            <p>Renew government documents easily and efficiently.</p></a>
        </div>

        <!-- Service 2 -->
        <div class="service">
            <a href="Hk9.html"><img src="deal.png" alt="Buy and Sell Icon">
            <h3>Sell and Buy</h3>
            <p>Manage buy and sell realestate securely.</p></a>
        </div>

        <!-- Service 3 -->
        <div class="service">
            <a href="Hk5.html"><img src="connection.png" alt="Organization Registration Icon">
            <h3>Registration</h3>
            <p>Register with government organizations & get your approvals.</p></a>
        </div>

        <!-- Service 4: Ministry of Labour Contracts -->
        <div class="service">
           <a href="Hk6.html"> <img src="travel.png" alt="Labour Contracts Icon">
            <h3>Other Services</h3>
            <p>Diverse services for varied needs.</p></a>
        </div>
    </div>

    <!-- Logout Section -->
    <div class="logout-container">
        <p>Click below to logout:</p>
        <form action="logout.php" method="POST">
            <button type="submit" class="logout-btn">Logout</button>
        </form>
    </div>
    </div>
</body>
</html>
