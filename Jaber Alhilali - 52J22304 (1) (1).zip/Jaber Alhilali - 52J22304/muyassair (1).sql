-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2024 at 03:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `muyassair`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_appointment`
--

CREATE TABLE `book_appointment` (
  `req_id` int(11) NOT NULL,
  `service` varchar(1) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(8) DEFAULT NULL,
  `nat_id` varchar(10) NOT NULL,
  `sel_time` time NOT NULL,
  `date` date NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_appointment`
--

INSERT INTO `book_appointment` (`req_id`, `service`, `full_name`, `phone_number`, `nat_id`, `sel_time`, `date`, `time`) VALUES
(1, 'B', 'hsjsjjd', '232', '24243', '44:55:45', '0000-00-00', '2024-11-30 17:18:47'),
(2, 'B', 'hsjsjjd', '232', '24243', '02:13:00', '0000-00-00', '2024-11-30 19:29:48'),
(3, 'B', 'hsjsjjd', '232', '24243', '02:13:00', '0000-00-00', '2024-11-30 19:30:39');

-- --------------------------------------------------------

--
-- Table structure for table `buliding_management`
--

CREATE TABLE `buliding_management` (
  `req_id` int(11) NOT NULL,
  `service` varchar(1) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(8) DEFAULT NULL,
  `nat_id` varchar(10) NOT NULL,
  `real_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buliding_management`
--

INSERT INTO `buliding_management` (`req_id`, `service`, `full_name`, `phone_number`, `nat_id`, `real_id`) VALUES
(1, 'B', 'jajajkjka', '181881', '0101001', '1122222');

-- --------------------------------------------------------

--
-- Table structure for table `commerial_rejesteration`
--

CREATE TABLE `commerial_rejesteration` (
  `id` int(11) NOT NULL,
  `service` varchar(20) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `nat_id` varchar(10) DEFAULT NULL,
  `phone_number` varchar(8) NOT NULL,
  `wilayah` varchar(20) DEFAULT NULL,
  `business_name` varchar(200) DEFAULT NULL,
  `business_ownership` varchar(20) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `commerial_rejesteration`
--

INSERT INTO `commerial_rejesteration` (`id`, `service`, `full_name`, `nat_id`, `phone_number`, `wilayah`, `business_name`, `business_ownership`, `time`) VALUES
(3, 'Commercial Register', 'Jaber Alhilai', '5211123', '97883783', 'Barka', 'edsd', 'Limited Liability Co', '2024-12-03 19:27:08');

-- --------------------------------------------------------

--
-- Table structure for table `consultations`
--

CREATE TABLE `consultations` (
  `req_id` int(11) NOT NULL,
  `service` varchar(1) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(8) DEFAULT NULL,
  `nat_id` varchar(10) DEFAULT NULL,
  `consultation_topic` varchar(5) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultations`
--

INSERT INTO `consultations` (`req_id`, `service`, `full_name`, `phone_number`, `nat_id`, `consultation_topic`, `time`) VALUES
(3, 'c', 'jaber', '97883783', '1556544', 'desig', '2024-12-01 18:39:22');

-- --------------------------------------------------------

--
-- Table structure for table `rejester`
--

CREATE TABLE `rejester` (
  `full_name` varchar(100) NOT NULL,
  `phone_number` varchar(8) NOT NULL,
  `wilayah` varchar(40) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rejester`
--

INSERT INTO `rejester` (`full_name`, `phone_number`, `wilayah`, `time`) VALUES
('salim', '77323783', 'Mussanah', '2024-12-08 17:08:20'),
('jfjfj', '87778999', 'Mussanah', '2024-12-17 09:47:24'),
('Jaber Alhilai', '97883783', 'Mussanah', '2024-12-08 17:03:21'),
('Juma Salim Alzahibi', '97883797', 'Saham Lamasat Polish ', '2024-12-04 08:59:41'),
('Ayoub alkasbi', '9939393', 'مال سيب سكر وحليب', '2024-12-04 09:03:32'),
('admin', 'admin', 'admin', '2024-12-13 20:44:00');

-- --------------------------------------------------------

--
-- Table structure for table `renew_documents`
--

CREATE TABLE `renew_documents` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `nat_id` varchar(10) NOT NULL,
  `phone` varchar(8) NOT NULL,
  `wilayah` varchar(4) NOT NULL,
  `service` varchar(4) NOT NULL,
  `expiry_date` date NOT NULL,
  `birth_date` date NOT NULL,
  `car_plate` varchar(7) NOT NULL,
  `time` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `renew_documents`
--

INSERT INTO `renew_documents` (`id`, `full_name`, `nat_id`, `phone`, `wilayah`, `service`, `expiry_date`, `birth_date`, `car_plate`, `time`) VALUES
(1, 'jaber alhilai', '1556544', '', 'bark', 'car', '0000-00-00', '0000-00-00', '22933/H', '0000-00-00 00:00:00.000000'),
(3, 'Jaber Alhilai', '1556544', '', 'Bark', 'Car', '0000-00-00', '0000-00-00', '33922/H', '0000-00-00 00:00:00.000000'),
(5, 'Jaber Alhilai', '1556544', '', 'Bark', 'Car', '0000-00-00', '0000-00-00', '33922/H', '0000-00-00 00:00:00.000000'),
(6, 'Jaber Alhilai', '1556544', '', 'Bark', 'Car', '0000-00-00', '0000-00-00', '33922/H', '2024-11-29 19:58:33.011402');

-- --------------------------------------------------------

--
-- Table structure for table `rent_home`
--

CREATE TABLE `rent_home` (
  `req_id` int(11) NOT NULL,
  `service` varchar(1) DEFAULT NULL,
  `t_full_name` varchar(100) DEFAULT NULL,
  `t_phone_number` varchar(8) DEFAULT NULL,
  `t_nat_id` varchar(10) DEFAULT NULL,
  `r_full_name` varchar(100) DEFAULT NULL,
  `r_phone_number` varchar(8) DEFAULT NULL,
  `r_nat_id` varchar(10) DEFAULT NULL,
  `realestate_id` varchar(20) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rent_home`
--

INSERT INTO `rent_home` (`req_id`, `service`, `t_full_name`, `t_phone_number`, `t_nat_id`, `r_full_name`, `r_phone_number`, `r_nat_id`, `realestate_id`, `time`) VALUES
(1, 'R', 'jsjjdjhjdd', '3333333', '3443323', 'dsdsd', '223323', '23332', '232323', '2024-11-30 15:41:36'),
(2, 'R', 'jsjjdjhjdd', '3333333', '3443323', 'dsdsd', '223323', '23332', '232323', '2024-11-30 15:49:53'),
(3, 'R', 'jsjjdjhjdd', '3333333', '3443323', 'dsdsd', '223323', '23332', '232323', '2024-12-03 17:45:37'),
(4, 'R', 'jsjjdjhjdd', '3333333', '3443323', 'dsdsd', '223323', '23332', '232323', '2024-12-03 17:46:36');

-- --------------------------------------------------------

--
-- Table structure for table `school_rejestration`
--

CREATE TABLE `school_rejestration` (
  `id` int(11) NOT NULL,
  `service` varchar(20) DEFAULT NULL,
  `g_full_name` varchar(100) DEFAULT NULL,
  `g_phone_number` varchar(8) DEFAULT NULL,
  `g_id` varchar(10) DEFAULT NULL,
  `wilayah` varchar(20) DEFAULT NULL,
  `home_address` varchar(40) DEFAULT NULL,
  `s_full_name` varchar(100) DEFAULT NULL,
  `s_passport` varchar(10) DEFAULT NULL,
  `s_age` varchar(2) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `school_rejestration`
--

INSERT INTO `school_rejestration` (`id`, `service`, `g_full_name`, `g_phone_number`, `g_id`, `wilayah`, `home_address`, `s_full_name`, `s_passport`, `s_age`, `time`) VALUES
(6, 'School Registration', 'dwd', 'wd', 'wd', 'Barka', 'wdwd', 'wdd', 'wdw', 'wd', '2024-12-03 18:49:48'),
(7, 'School Registration', 'dwd', 'dsdw', 'sd3', 'Rustaq', 'wdwd', 'wdd', 'wdw', 'wd', '2024-12-03 19:09:41');

-- --------------------------------------------------------

--
-- Table structure for table `support_outside_country`
--

CREATE TABLE `support_outside_country` (
  `req_id` int(11) NOT NULL,
  `service` varchar(1) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(8) NOT NULL,
  `nat_id` varchar(10) NOT NULL,
  `need_support` varchar(1) DEFAULT NULL,
  `another_full_name` varchar(100) DEFAULT NULL,
  `another_phone_number` varchar(8) DEFAULT NULL,
  `another_id` varchar(10) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `travelling_visa`
--

CREATE TABLE `travelling_visa` (
  `req_id` int(11) NOT NULL,
  `service` varchar(1) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(8) DEFAULT NULL,
  `nat_id` varchar(10) DEFAULT NULL,
  `passport` varchar(10) DEFAULT NULL,
  `country_travel` varchar(60) DEFAULT NULL,
  `term` varchar(1) CHARACTER SET sjis COLLATE sjis_bin DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_appointment`
--
ALTER TABLE `book_appointment`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `phone_number` (`phone_number`);

--
-- Indexes for table `buliding_management`
--
ALTER TABLE `buliding_management`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `phone_number` (`phone_number`);

--
-- Indexes for table `commerial_rejesteration`
--
ALTER TABLE `commerial_rejesteration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `phone_number` (`phone_number`);

--
-- Indexes for table `consultations`
--
ALTER TABLE `consultations`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `phone_number` (`phone_number`);

--
-- Indexes for table `rejester`
--
ALTER TABLE `rejester`
  ADD PRIMARY KEY (`phone_number`);

--
-- Indexes for table `renew_documents`
--
ALTER TABLE `renew_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `phone` (`phone`);

--
-- Indexes for table `rent_home`
--
ALTER TABLE `rent_home`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `t_phone_number` (`t_phone_number`);

--
-- Indexes for table `school_rejestration`
--
ALTER TABLE `school_rejestration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `g_phone_number` (`g_phone_number`);

--
-- Indexes for table `support_outside_country`
--
ALTER TABLE `support_outside_country`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `phone_number` (`phone_number`);

--
-- Indexes for table `travelling_visa`
--
ALTER TABLE `travelling_visa`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `phone_number` (`phone_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_appointment`
--
ALTER TABLE `book_appointment`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `buliding_management`
--
ALTER TABLE `buliding_management`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `commerial_rejesteration`
--
ALTER TABLE `commerial_rejesteration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `consultations`
--
ALTER TABLE `consultations`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `renew_documents`
--
ALTER TABLE `renew_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rent_home`
--
ALTER TABLE `rent_home`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `school_rejestration`
--
ALTER TABLE `school_rejestration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `support_outside_country`
--
ALTER TABLE `support_outside_country`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `travelling_visa`
--
ALTER TABLE `travelling_visa`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `support_outside_country`
--
ALTER TABLE `support_outside_country`
  ADD CONSTRAINT `taset` FOREIGN KEY (`phone_number`) REFERENCES `users` (`phone`),
  ADD CONSTRAINT `test2` FOREIGN KEY (`nat_id`) REFERENCES `users` (`nat_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
