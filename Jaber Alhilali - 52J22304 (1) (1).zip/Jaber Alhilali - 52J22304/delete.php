<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "muyassair";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
$phone = $_POST['phone-number'];
}
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to delete a record
$sql = "DELETE FROM rejester WHERE phone_number=$phone ";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>