<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "muyassair";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $fname = $_POST['full-name'];
	$phone = $_POST['phone-number'];
	$id = $_POST['id'];
    $dep = $_POST['wilayah'];
	$ser = $_POST['service'];
	$dob = $_POST['dob'];
	$ex = $_POST['expiry-date'];
    $add = $_POST['car-plate-number'];
	
    
 

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO renew_documents(full_name, nat_id, phone,  wilayah, service, expiry_date, birth_date, car_plate)
  VALUES ('$fname', '$id', '$phone', '$dep', '$ser', '$ex', '$dob', '$add')";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
}

$conn = null;
?>